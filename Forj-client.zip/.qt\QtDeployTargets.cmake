set(__QT_DEPLOY_TARGET_Forj_FILE E:/Projects_other/Discord_Replacement/client/build/Forj.exe)
set(__QT_DEPLOY_TARGET_Forj_TYPE EXECUTABLE)
set(__QT_DEPLOY_TARGET_Forj_RUNTIME_DLLS C:/msys64/mingw64/bin/Qt6Widgets.dll;C:/msys64/mingw64/bin/Qt6WebSockets.dll;C:/msys64/mingw64/bin/Qt6Gui.dll;C:/msys64/mingw64/bin/Qt6Network.dll;C:/msys64/mingw64/bin/Qt6Core.dll)
