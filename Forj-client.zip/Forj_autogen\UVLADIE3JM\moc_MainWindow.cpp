/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/MainWindow.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN10MainWindowE_t {};
} // unnamed namespace

template <> constexpr inline auto MainWindow::qt_create_metaobjectdata<qt_meta_tag_ZN10MainWindowE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "MainWindow",
        "onGuildSelected",
        "",
        "row",
        "onChannelSelected",
        "onDmSelected",
        "onSendMessage",
        "onCreateGuildClicked",
        "onJoinGuildClicked",
        "onCreateChannelClicked",
        "onOpenDmClicked",
        "onSettingsClicked",
        "onNotifyClicked",
        "onFriendsClicked",
        "onFriendRequest",
        "fromId",
        "fromUsername",
        "fromDisplayName",
        "onFriendAccepted",
        "byId",
        "byUsername",
        "byDisplayName",
        "onGuildInviteReceived",
        "guildId",
        "guildName",
        "inviteCode",
        "inviterUsername",
        "onInviteToGuildRequested",
        "userId",
        "username",
        "onChannelContextMenu",
        "QPoint",
        "pos",
        "onGuildContextMenu",
        "onVoiceJoin",
        "channelId",
        "onVoiceLeave",
        "onLeaveVoiceClicked",
        "onVoiceSpeaking",
        "speaking",
        "onNewMessage",
        "MessageInfo",
        "msg",
        "onNewDmMessage",
        "DmMessageInfo",
        "onUserOnline",
        "onUserOffline",
        "onUserStatusChanged",
        "status",
        "onMentioned",
        "channelName",
        "author",
        "content",
        "onInputChanged",
        "text"
    };

    QtMocHelpers::UintData qt_methods {
        // Slot 'onGuildSelected'
        QtMocHelpers::SlotData<void(int)>(1, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 3 },
        }}),
        // Slot 'onChannelSelected'
        QtMocHelpers::SlotData<void(int)>(4, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 3 },
        }}),
        // Slot 'onDmSelected'
        QtMocHelpers::SlotData<void(int)>(5, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 3 },
        }}),
        // Slot 'onSendMessage'
        QtMocHelpers::SlotData<void()>(6, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onCreateGuildClicked'
        QtMocHelpers::SlotData<void()>(7, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onJoinGuildClicked'
        QtMocHelpers::SlotData<void()>(8, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onCreateChannelClicked'
        QtMocHelpers::SlotData<void()>(9, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onOpenDmClicked'
        QtMocHelpers::SlotData<void()>(10, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onSettingsClicked'
        QtMocHelpers::SlotData<void()>(11, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onNotifyClicked'
        QtMocHelpers::SlotData<void()>(12, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onFriendsClicked'
        QtMocHelpers::SlotData<void()>(13, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onFriendRequest'
        QtMocHelpers::SlotData<void(int, const QString &, const QString &)>(14, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 15 }, { QMetaType::QString, 16 }, { QMetaType::QString, 17 },
        }}),
        // Slot 'onFriendAccepted'
        QtMocHelpers::SlotData<void(int, const QString &, const QString &)>(18, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 19 }, { QMetaType::QString, 20 }, { QMetaType::QString, 21 },
        }}),
        // Slot 'onGuildInviteReceived'
        QtMocHelpers::SlotData<void(int, const QString &, const QString &, const QString &)>(22, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 23 }, { QMetaType::QString, 24 }, { QMetaType::QString, 25 }, { QMetaType::QString, 26 },
        }}),
        // Slot 'onInviteToGuildRequested'
        QtMocHelpers::SlotData<void(int, const QString &)>(27, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 28 }, { QMetaType::QString, 29 },
        }}),
        // Slot 'onChannelContextMenu'
        QtMocHelpers::SlotData<void(const QPoint &)>(30, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 31, 32 },
        }}),
        // Slot 'onGuildContextMenu'
        QtMocHelpers::SlotData<void(const QPoint &)>(33, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 31, 32 },
        }}),
        // Slot 'onVoiceJoin'
        QtMocHelpers::SlotData<void(int, int, const QString &)>(34, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 35 }, { QMetaType::Int, 28 }, { QMetaType::QString, 29 },
        }}),
        // Slot 'onVoiceLeave'
        QtMocHelpers::SlotData<void(int, int, const QString &)>(36, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 35 }, { QMetaType::Int, 28 }, { QMetaType::QString, 29 },
        }}),
        // Slot 'onLeaveVoiceClicked'
        QtMocHelpers::SlotData<void()>(37, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onVoiceSpeaking'
        QtMocHelpers::SlotData<void(int, int, bool)>(38, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 35 }, { QMetaType::Int, 28 }, { QMetaType::Bool, 39 },
        }}),
        // Slot 'onNewMessage'
        QtMocHelpers::SlotData<void(const MessageInfo &)>(40, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 41, 42 },
        }}),
        // Slot 'onNewDmMessage'
        QtMocHelpers::SlotData<void(const DmMessageInfo &)>(43, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { 0x80000000 | 44, 42 },
        }}),
        // Slot 'onUserOnline'
        QtMocHelpers::SlotData<void(int, const QString &)>(45, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 28 }, { QMetaType::QString, 29 },
        }}),
        // Slot 'onUserOffline'
        QtMocHelpers::SlotData<void(int, const QString &)>(46, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 28 }, { QMetaType::QString, 29 },
        }}),
        // Slot 'onUserStatusChanged'
        QtMocHelpers::SlotData<void(int, const QString &, const QString &)>(47, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 28 }, { QMetaType::QString, 29 }, { QMetaType::QString, 48 },
        }}),
        // Slot 'onMentioned'
        QtMocHelpers::SlotData<void(int, int, const QString &, const QString &, const QString &)>(49, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 23 }, { QMetaType::Int, 35 }, { QMetaType::QString, 50 }, { QMetaType::QString, 51 },
            { QMetaType::QString, 52 },
        }}),
        // Slot 'onInputChanged'
        QtMocHelpers::SlotData<void(const QString &)>(53, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::QString, 54 },
        }}),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<MainWindow, qt_meta_tag_ZN10MainWindowE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN10MainWindowE_t>.metaTypes,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<MainWindow *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->onGuildSelected((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->onChannelSelected((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->onDmSelected((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->onSendMessage(); break;
        case 4: _t->onCreateGuildClicked(); break;
        case 5: _t->onJoinGuildClicked(); break;
        case 6: _t->onCreateChannelClicked(); break;
        case 7: _t->onOpenDmClicked(); break;
        case 8: _t->onSettingsClicked(); break;
        case 9: _t->onNotifyClicked(); break;
        case 10: _t->onFriendsClicked(); break;
        case 11: _t->onFriendRequest((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 12: _t->onFriendAccepted((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 13: _t->onGuildInviteReceived((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[4]))); break;
        case 14: _t->onInviteToGuildRequested((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 15: _t->onChannelContextMenu((*reinterpret_cast<std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 16: _t->onGuildContextMenu((*reinterpret_cast<std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 17: _t->onVoiceJoin((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 18: _t->onVoiceLeave((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 19: _t->onLeaveVoiceClicked(); break;
        case 20: _t->onVoiceSpeaking((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<bool>>(_a[3]))); break;
        case 21: _t->onNewMessage((*reinterpret_cast<std::add_pointer_t<MessageInfo>>(_a[1]))); break;
        case 22: _t->onNewDmMessage((*reinterpret_cast<std::add_pointer_t<DmMessageInfo>>(_a[1]))); break;
        case 23: _t->onUserOnline((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 24: _t->onUserOffline((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2]))); break;
        case 25: _t->onUserStatusChanged((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3]))); break;
        case 26: _t->onMentioned((*reinterpret_cast<std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast<std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[3])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[4])),(*reinterpret_cast<std::add_pointer_t<QString>>(_a[5]))); break;
        case 27: _t->onInputChanged((*reinterpret_cast<std::add_pointer_t<QString>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN10MainWindowE_t>.strings))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
