/****************************************************************************
** Meta object code from reading C++ file 'ServerSettingsDialog.h'
**
** Created by: The Qt Meta Object Compiler version 69 (Qt 6.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/ServerSettingsDialog.h"
#include <QtGui/qtextcursor.h>
#include <QtNetwork/QSslError>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'ServerSettingsDialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 69
#error "This file was generated using the moc from 6.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {
struct qt_meta_tag_ZN20ServerSettingsDialogE_t {};
} // unnamed namespace

template <> constexpr inline auto ServerSettingsDialog::qt_create_metaobjectdata<qt_meta_tag_ZN20ServerSettingsDialogE_t>()
{
    namespace QMC = QtMocConstants;
    QtMocHelpers::StringRefStorage qt_stringData {
        "ServerSettingsDialog",
        "onSaveOverview",
        "",
        "onPickIcon",
        "onCreateRole",
        "onDeleteRole",
        "onRoleSelected",
        "row",
        "onSaveRole",
        "onMemberSelected",
        "onKickMember",
        "onBanMember",
        "onAssignRole",
        "onRemoveRoleFromMember",
        "onUnban",
        "onSaveMyProfile",
        "onPickServerAvatar",
        "onCreateBot",
        "onDeleteBot",
        "onResetBotToken",
        "onRegisterCommand",
        "onDeleteCommand",
        "refreshBotList",
        "refreshCommandList"
    };

    QtMocHelpers::UintData qt_methods {
        // Slot 'onSaveOverview'
        QtMocHelpers::SlotData<void()>(1, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onPickIcon'
        QtMocHelpers::SlotData<void()>(3, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onCreateRole'
        QtMocHelpers::SlotData<void()>(4, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onDeleteRole'
        QtMocHelpers::SlotData<void()>(5, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onRoleSelected'
        QtMocHelpers::SlotData<void(int)>(6, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 7 },
        }}),
        // Slot 'onSaveRole'
        QtMocHelpers::SlotData<void()>(8, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onMemberSelected'
        QtMocHelpers::SlotData<void(int)>(9, 2, QMC::AccessPrivate, QMetaType::Void, {{
            { QMetaType::Int, 7 },
        }}),
        // Slot 'onKickMember'
        QtMocHelpers::SlotData<void()>(10, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onBanMember'
        QtMocHelpers::SlotData<void()>(11, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onAssignRole'
        QtMocHelpers::SlotData<void()>(12, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onRemoveRoleFromMember'
        QtMocHelpers::SlotData<void()>(13, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onUnban'
        QtMocHelpers::SlotData<void()>(14, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onSaveMyProfile'
        QtMocHelpers::SlotData<void()>(15, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onPickServerAvatar'
        QtMocHelpers::SlotData<void()>(16, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onCreateBot'
        QtMocHelpers::SlotData<void()>(17, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onDeleteBot'
        QtMocHelpers::SlotData<void()>(18, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onResetBotToken'
        QtMocHelpers::SlotData<void()>(19, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onRegisterCommand'
        QtMocHelpers::SlotData<void()>(20, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'onDeleteCommand'
        QtMocHelpers::SlotData<void()>(21, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'refreshBotList'
        QtMocHelpers::SlotData<void()>(22, 2, QMC::AccessPrivate, QMetaType::Void),
        // Slot 'refreshCommandList'
        QtMocHelpers::SlotData<void()>(23, 2, QMC::AccessPrivate, QMetaType::Void),
    };
    QtMocHelpers::UintData qt_properties {
    };
    QtMocHelpers::UintData qt_enums {
    };
    return QtMocHelpers::metaObjectData<ServerSettingsDialog, qt_meta_tag_ZN20ServerSettingsDialogE_t>(QMC::MetaObjectFlag{}, qt_stringData,
            qt_methods, qt_properties, qt_enums);
}
Q_CONSTINIT const QMetaObject ServerSettingsDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<ForjDialog::staticMetaObject>(),
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN20ServerSettingsDialogE_t>.stringdata,
    qt_staticMetaObjectStaticContent<qt_meta_tag_ZN20ServerSettingsDialogE_t>.data,
    qt_static_metacall,
    nullptr,
    qt_staticMetaObjectRelocatingContent<qt_meta_tag_ZN20ServerSettingsDialogE_t>.metaTypes,
    nullptr
} };

void ServerSettingsDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    auto *_t = static_cast<ServerSettingsDialog *>(_o);
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: _t->onSaveOverview(); break;
        case 1: _t->onPickIcon(); break;
        case 2: _t->onCreateRole(); break;
        case 3: _t->onDeleteRole(); break;
        case 4: _t->onRoleSelected((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->onSaveRole(); break;
        case 6: _t->onMemberSelected((*reinterpret_cast<std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->onKickMember(); break;
        case 8: _t->onBanMember(); break;
        case 9: _t->onAssignRole(); break;
        case 10: _t->onRemoveRoleFromMember(); break;
        case 11: _t->onUnban(); break;
        case 12: _t->onSaveMyProfile(); break;
        case 13: _t->onPickServerAvatar(); break;
        case 14: _t->onCreateBot(); break;
        case 15: _t->onDeleteBot(); break;
        case 16: _t->onResetBotToken(); break;
        case 17: _t->onRegisterCommand(); break;
        case 18: _t->onDeleteCommand(); break;
        case 19: _t->refreshBotList(); break;
        case 20: _t->refreshCommandList(); break;
        default: ;
        }
    }
}

const QMetaObject *ServerSettingsDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ServerSettingsDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_staticMetaObjectStaticContent<qt_meta_tag_ZN20ServerSettingsDialogE_t>.strings))
        return static_cast<void*>(this);
    return ForjDialog::qt_metacast(_clname);
}

int ServerSettingsDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ForjDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 21)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 21;
    }
    if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 21)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 21;
    }
    return _id;
}
QT_WARNING_POP
